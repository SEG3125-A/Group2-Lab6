Here is our Lab 1 for the SEG 3125 course, you can find the code for our main page named walmart.html, the second page named thankyou.html and finally the css which belongs to walmart.css.
"walmart-homepage-April-3.webp" is just the image used for our main survey page as a reference.
Malick Ndoye 300147470
Farid Ouedraogo 300206842
Elie N. Ndoumaï
