const fs = require('fs');

app.post('/submit-survey', (req, res) => {
    // Read the existing data
    fs.readFile('survey-results.json', (err, data) => {
        if (err && err.code === 'ENOENT') {
            // If the file doesn't exist, start with an empty array
            data = '[]';
        } else if (err) {
            throw err; // Handle other potential errors
        }

        // Parse the existing data
        const surveys = JSON.parse(data);
        
        // Add the new survey
        surveys.push(req.body);
        
        // Write the updated array back to the file
        fs.writeFile('survey-results.json', JSON.stringify(surveys, null, 2), err => {
            if (err) throw err;
            res.send('Survey submitted successfully!');
        });
    });
});
