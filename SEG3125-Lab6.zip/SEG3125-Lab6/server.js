const express = require('express');
const fs = require('fs');
const app = express();
const PORT = 3000;


app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static('public')); // Serve static files from 'public' directory

app.post('/submit-survey', (req, res) => {
    fs.readFile('survey-results.json', (err, data) => {
        let surveys = [];
        if (!err) {
            surveys = JSON.parse(data.toString()); // parse the existing data
        }
        
        surveys.push(req.body); //the new survey 
        
        fs.writeFile('survey-results.json', JSON.stringify(surveys, null, 2), (err) => {
            if (err) {
                console.error(err);
                return res.status(500).send('Error saving survey data.');
            }
            res.send('Survey submitted successfully!');
        });
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
//http://localhost:3000/walmart.html